package com.atguigu.team.service;

//表示员工的状态
public enum Status {
	FREE,BUSY,VOCATION;
}
