package com.atguigu06.project.model.service;

public class TeamException extends Exception {
	static final long serialVersionUID = -33875169124229948L;

	public TeamException() {
	}

	public TeamException(String message) {
		super(message);
	}
}
