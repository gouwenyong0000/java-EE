package com.atguigu06.project.model.domain;

public interface Equipment {
	
	String getDescription();
}
