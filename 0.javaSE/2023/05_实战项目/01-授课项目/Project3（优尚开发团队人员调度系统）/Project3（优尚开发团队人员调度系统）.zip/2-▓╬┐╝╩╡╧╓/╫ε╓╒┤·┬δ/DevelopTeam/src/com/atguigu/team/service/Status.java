package com.atguigu06.project.model.service;

public enum Status {
    FREE, BUSY, VOCATION
}
