package com.atguigu.snake;

public enum Dir {
    /**
     * L:向左
     * U:向上
     * R:向右
     * D:向下
     */
    L, U, R, D
}
