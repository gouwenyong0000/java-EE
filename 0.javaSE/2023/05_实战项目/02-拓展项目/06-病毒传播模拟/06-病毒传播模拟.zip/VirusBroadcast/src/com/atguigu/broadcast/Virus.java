package com.atguigu.broadcast;

/**
 * 病毒对象
 *
 * @ClassName: Virus
 * @Description: 病毒对象
 */
public class Virus {
}
