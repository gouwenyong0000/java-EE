package cn.test;

import cn.tools.AliyunSms;

public class TestSms {

	public static void main(String[] args) {
		AliyunSms.sendSms("17380566800", "6666");
	}

}
