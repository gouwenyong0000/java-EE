package com.example.instrument.api;

public interface ConnectionListener {
    default void onConnected() {}
    default void onDisconnected(Throwable cause) {}
    default void onReconnecting(int attempt, java.time.Duration delay, Throwable cause) {}
    default void onReconnectFailed(Throwable cause) {}
}
