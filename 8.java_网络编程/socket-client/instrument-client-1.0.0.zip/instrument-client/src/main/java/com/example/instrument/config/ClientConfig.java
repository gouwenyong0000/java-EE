package com.example.instrument.config;

import java.net.SocketOption;
import java.time.Duration;
import java.util.Objects;

public final class ClientConfig {
    private final Duration connectTimeout;
    private final Duration responseTimeout;
    private final int socketReadTimeoutMillis;
    private final int receiveBufferSize;
    private final int asyncQueueCapacity;
    private final OverflowPolicy overflowPolicy;
    private final boolean tcpNoDelay;
    private final boolean keepAlive;
    private final ReconnectConfig reconnect;

    private ClientConfig(Builder b) {
        connectTimeout=b.connectTimeout; responseTimeout=b.responseTimeout; socketReadTimeoutMillis=b.socketReadTimeoutMillis;
        receiveBufferSize=b.receiveBufferSize; asyncQueueCapacity=b.asyncQueueCapacity; overflowPolicy=b.overflowPolicy;
        tcpNoDelay=b.tcpNoDelay; keepAlive=b.keepAlive; reconnect=b.reconnect;
    }
    public static Builder builder() { return new Builder(); }
    public static ClientConfig defaults() { return builder().build(); }
    public Duration connectTimeout(){return connectTimeout;}
    public Duration responseTimeout(){return responseTimeout;}
    public int socketReadTimeoutMillis(){return socketReadTimeoutMillis;}
    public int receiveBufferSize(){return receiveBufferSize;}
    public int asyncQueueCapacity(){return asyncQueueCapacity;}
    public OverflowPolicy overflowPolicy(){return overflowPolicy;}
    public boolean tcpNoDelay(){return tcpNoDelay;}
    public boolean keepAlive(){return keepAlive;}
    public ReconnectConfig reconnect(){return reconnect;}

    public enum OverflowPolicy { DROP_OLDEST, DROP_NEWEST, BLOCK, FAIL }

    public static final class Builder {
        private Duration connectTimeout=Duration.ofSeconds(5), responseTimeout=Duration.ofSeconds(10);
        private int socketReadTimeoutMillis=0, receiveBufferSize=8192, asyncQueueCapacity=256;
        private OverflowPolicy overflowPolicy=OverflowPolicy.DROP_OLDEST;
        private boolean tcpNoDelay=true, keepAlive=true;
        private ReconnectConfig reconnect=ReconnectConfig.defaults();
        public Builder connectTimeout(Duration v){connectTimeout=Objects.requireNonNull(v);return this;}
        public Builder responseTimeout(Duration v){responseTimeout=Objects.requireNonNull(v);return this;}
        public Builder socketReadTimeoutMillis(int v){if(v<0)throw new IllegalArgumentException();socketReadTimeoutMillis=v;return this;}
        public Builder receiveBufferSize(int v){if(v<=0)throw new IllegalArgumentException();receiveBufferSize=v;return this;}
        public Builder asyncQueueCapacity(int v){if(v<=0)throw new IllegalArgumentException();asyncQueueCapacity=v;return this;}
        public Builder overflowPolicy(OverflowPolicy v){overflowPolicy=Objects.requireNonNull(v);return this;}
        public Builder tcpNoDelay(boolean v){tcpNoDelay=v;return this;}
        public Builder keepAlive(boolean v){keepAlive=v;return this;}
        public Builder reconnect(ReconnectConfig v){reconnect=Objects.requireNonNull(v);return this;}
        public ClientConfig build(){return new ClientConfig(this);}
    }
}
