package com.example.instrument.model;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;

public final class Response {
    private final byte[] frame;
    private final byte[] body;
    private final long receivedAtNanos;

    public Response(byte[] frame, byte[] body) {
        this(frame, body, System.nanoTime());
    }

    public Response(byte[] frame, byte[] body, long receivedAtNanos) {
        this.frame = Objects.requireNonNull(frame).clone();
        this.body = Objects.requireNonNull(body).clone();
        this.receivedAtNanos = receivedAtNanos;
    }

    public byte[] bytes() { return frame.clone(); }
    public byte[] body() { return body.clone(); }
    public int length() { return frame.length; }
    public long receivedAtNanos() { return receivedAtNanos; }
    public String text() { return text(StandardCharsets.UTF_8); }
    public String text(Charset charset) { return new String(body, Objects.requireNonNull(charset)); }

    @Override public String toString() { return "Response[length=" + frame.length + ", bodyLength=" + body.length + "]"; }
    @Override public boolean equals(Object o) {
        return o instanceof Response r && Arrays.equals(frame, r.frame) && Arrays.equals(body, r.body);
    }
    @Override public int hashCode() { return 31 * Arrays.hashCode(frame) + Arrays.hashCode(body); }
}
