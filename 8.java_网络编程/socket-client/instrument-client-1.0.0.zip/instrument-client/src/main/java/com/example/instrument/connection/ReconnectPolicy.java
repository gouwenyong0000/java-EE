package com.example.instrument.connection;

import com.example.instrument.config.ReconnectConfig;
import java.time.Duration;
import java.util.Objects;

public final class ReconnectPolicy {
    private final ReconnectConfig config;
    public ReconnectPolicy(ReconnectConfig config){this.config=Objects.requireNonNull(config);}
    public boolean enabled(){return config.enabled() && config.maxAttempts()>0;}
    public boolean canAttempt(int attempt){return enabled() && attempt<=config.maxAttempts();}
    public Duration delay(int attempt){return config.delayForAttempt(attempt);}
    public int maxAttempts(){return config.maxAttempts();}
}
