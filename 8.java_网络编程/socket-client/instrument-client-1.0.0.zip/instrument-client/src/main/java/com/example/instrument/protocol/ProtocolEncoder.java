package com.example.instrument.protocol;

import com.example.instrument.model.Command;

@FunctionalInterface
public interface ProtocolEncoder {
    byte[] encode(Command command);
}
