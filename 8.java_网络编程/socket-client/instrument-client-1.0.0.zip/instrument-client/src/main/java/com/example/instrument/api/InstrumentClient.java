package com.example.instrument.api;

import com.example.instrument.model.Command;
import com.example.instrument.model.CommandIdempotency;
import com.example.instrument.model.Response;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

public interface InstrumentClient extends AutoCloseable {
    void connect();
    void disconnect();
    boolean isConnected();
    Response request(Command command, ResponseMatcher matcher, Duration timeout, CommandIdempotency idempotency);
    default Response request(Command command, ResponseMatcher matcher, Duration timeout) {
        return request(command, matcher, timeout, CommandIdempotency.UNKNOWN);
    }
    CompletableFuture<Response> requestAsync(Command command, ResponseMatcher matcher, Duration timeout,
                                              CommandIdempotency idempotency);
    void send(Command command);
    void addDataListener(DataListener listener);
    void removeDataListener(DataListener listener);
    void addConnectionListener(ConnectionListener listener);
    void removeConnectionListener(ConnectionListener listener);
    BlockingDataListener blockingDataListener();
    @Override void close();
}
