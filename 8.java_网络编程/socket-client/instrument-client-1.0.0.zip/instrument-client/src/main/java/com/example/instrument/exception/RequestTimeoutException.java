package com.example.instrument.exception;

public class RequestTimeoutException extends InstrumentException {
    public RequestTimeoutException(String message) { super(message); }
}
