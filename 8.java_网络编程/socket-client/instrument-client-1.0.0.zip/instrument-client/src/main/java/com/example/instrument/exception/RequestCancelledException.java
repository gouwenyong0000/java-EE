package com.example.instrument.exception;

public class RequestCancelledException extends InstrumentException {
    public RequestCancelledException(String message) { super(message); }
}
