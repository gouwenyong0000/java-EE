package com.example.instrument.model;

public enum CommandIdempotency {
    IDEMPOTENT,
    NON_IDEMPOTENT,
    UNKNOWN
}
