package com.example.instrument.core;

import com.example.instrument.api.ResponseMatcher;
import com.example.instrument.model.Response;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

final class PendingRequest {
    private final ResponseMatcher matcher;
    private final CompletableFuture<Response> future=new CompletableFuture<>();
    PendingRequest(ResponseMatcher matcher){this.matcher=Objects.requireNonNull(matcher);}
    boolean tryComplete(Response response){
        if(matcher.matches(response)) return future.complete(response);
        return false;
    }
    CompletableFuture<Response> future(){return future;}
}
