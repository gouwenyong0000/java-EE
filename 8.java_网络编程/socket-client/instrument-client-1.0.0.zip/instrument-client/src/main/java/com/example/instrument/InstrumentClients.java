package com.example.instrument;

import com.example.instrument.api.InstrumentClient;
import com.example.instrument.config.ClientConfig;
import com.example.instrument.core.InstrumentClientImpl;
import com.example.instrument.protocol.Protocol;
import java.net.InetSocketAddress;
import java.util.Objects;

public final class InstrumentClients {
    private InstrumentClients() {}
    public static InstrumentClient tcp(InetSocketAddress address,Protocol protocol,ClientConfig config){
        return new InstrumentClientImpl(Objects.requireNonNull(address),Objects.requireNonNull(protocol),Objects.requireNonNull(config));
    }
    public static InstrumentClient tcp(String host,int port,Protocol protocol,ClientConfig config){
        return tcp(new InetSocketAddress(host,port),protocol,config);
    }
}
