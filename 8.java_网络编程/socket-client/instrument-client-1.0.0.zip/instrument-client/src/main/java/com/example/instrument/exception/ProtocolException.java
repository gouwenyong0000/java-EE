package com.example.instrument.exception;

public class ProtocolException extends InstrumentException {
    public ProtocolException(String message) { super(message); }
    public ProtocolException(String message, Throwable cause) { super(message, cause); }
}
