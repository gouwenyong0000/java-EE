package com.example.instrument.core;

import com.example.instrument.api.DataListener;
import com.example.instrument.config.ClientConfig;
import com.example.instrument.metrics.ClientMetrics;
import com.example.instrument.model.Response;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.BlockingQueue;

final class ResponseDispatcher {
    private final RequestManager requestManager; private final ClientConfig.OverflowPolicy overflowPolicy;
    private final BlockingQueue<Response> asyncQueue; private final CopyOnWriteArrayList<DataListener> listeners=new CopyOnWriteArrayList<>();
    private final ClientMetrics metrics;
    ResponseDispatcher(RequestManager requestManager,ClientConfig config,ClientMetrics metrics){
        this.requestManager=Objects.requireNonNull(requestManager);overflowPolicy=config.overflowPolicy();asyncQueue=new ArrayBlockingQueue<>(config.asyncQueueCapacity());this.metrics=metrics;
    }
    void dispatch(Response response){
        if(requestManager.dispatch(response)){metrics.receivedMatched();return;}
        metrics.receivedAsync(); offer(response); for(DataListener listener:listeners){try{listener.onData(response);}catch(Throwable t){metrics.listenerErrors();}}
    }
    private void offer(Response response){
        switch(overflowPolicy){
            case DROP_NEWEST -> {if(!asyncQueue.offer(response))metrics.droppedAsync();}
            case DROP_OLDEST -> {if(!asyncQueue.offer(response)){asyncQueue.poll();if(!asyncQueue.offer(response))metrics.droppedAsync();}}
            case BLOCK -> {try{asyncQueue.put(response);}catch(InterruptedException e){Thread.currentThread().interrupt();metrics.droppedAsync();}}
            case FAIL -> {if(!asyncQueue.offer(response))throw new IllegalStateException("async response queue is full");}
        }
    }
    void addListener(DataListener listener){listeners.add(Objects.requireNonNull(listener));}
    void removeListener(DataListener listener){listeners.remove(listener);}
    BlockingQueue<Response> queue(){return asyncQueue;}
    void clearQueue(){asyncQueue.clear();}
}
