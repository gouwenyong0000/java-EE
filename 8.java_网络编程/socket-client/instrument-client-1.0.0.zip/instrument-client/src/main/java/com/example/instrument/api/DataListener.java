package com.example.instrument.api;

import com.example.instrument.model.Response;

@FunctionalInterface
public interface DataListener {
    void onData(Response response);
}
