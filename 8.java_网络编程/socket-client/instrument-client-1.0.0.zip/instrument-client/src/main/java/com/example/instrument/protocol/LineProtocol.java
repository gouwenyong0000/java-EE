package com.example.instrument.protocol;

import com.example.instrument.exception.ProtocolException;
import com.example.instrument.model.Command;
import com.example.instrument.model.Response;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public final class LineProtocol implements Protocol {
    private final byte[] delimiter;
    private final Charset charset;
    private final int maxFrameLength;

    private LineProtocol(byte[] delimiter, Charset charset, int maxFrameLength) {
        this.delimiter=delimiter.clone(); this.charset=Objects.requireNonNull(charset); this.maxFrameLength=maxFrameLength;
        if (delimiter.length == 0) throw new IllegalArgumentException("delimiter is empty");
        if (maxFrameLength <= delimiter.length) throw new IllegalArgumentException("maxFrameLength too small");
    }
    public static LineProtocol crlf(Charset charset) { return new LineProtocol(new byte[]{'\r','\n'}, charset, 1024 * 1024); }
    public static LineProtocol lf(Charset charset) { return new LineProtocol(new byte[]{'\n'}, charset, 1024 * 1024); }
    public LineProtocol withMaxFrameLength(int max) { return new LineProtocol(delimiter, charset, max); }
    @Override public Charset charset(){return charset;}
    @Override public ProtocolEncoder newEncoder() {
        return command -> {
            byte[] body=command.bytes();
            byte[] out=Arrays.copyOf(body, body.length + delimiter.length);
            System.arraycopy(delimiter,0,out,body.length,delimiter.length);
            return out;
        };
    }
    @Override public ProtocolDecoder newDecoder() { return new Decoder(delimiter, maxFrameLength); }

    private static final class Decoder implements ProtocolDecoder {
        private final byte[] delimiter; private final int max; private final ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        Decoder(byte[] delimiter,int max){this.delimiter=delimiter.clone();this.max=max;}
        @Override public synchronized List<Response> decode(byte[] data,int offset,int length){
            if(length==0)return List.of();
            if(offset<0||length<0||offset+length>data.length)throw new IndexOutOfBoundsException();
            buffer.write(data,offset,length);
            if(buffer.size()>max+delimiter.length) throw new ProtocolException("line frame exceeds max length: "+max);
            byte[] bytes=buffer.toByteArray(); List<Response> out=new ArrayList<>(); int start=0;
            while(true){
                int pos=indexOf(bytes,delimiter,start); if(pos<0)break;
                int frameEnd=pos+delimiter.length; int bodyLen=pos-start;
                byte[] frame=Arrays.copyOfRange(bytes,start,frameEnd);
                byte[] body=Arrays.copyOfRange(bytes,start,pos);
                out.add(new Response(frame,body)); start=frameEnd;
            }
            if(start>0){buffer.reset();buffer.write(bytes,start,bytes.length-start);}
            if(buffer.size()>max) throw new ProtocolException("line frame exceeds max length: "+max);
            return out;
        }
        private static int indexOf(byte[] data,byte[] target,int from){
            outer: for(int i=from;i<=data.length-target.length;i++){for(int j=0;j<target.length;j++)if(data[i+j]!=target[j])continue outer;return i;} return -1;
        }
        @Override public synchronized void reset(){buffer.reset();}
    }
}
