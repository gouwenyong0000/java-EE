package com.example.instrument.exception;

public class ConnectionException extends InstrumentException {
    public ConnectionException(String message) { super(message); }
    public ConnectionException(String message, Throwable cause) { super(message, cause); }
}
