package com.example.instrument.config;

import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public record ReconnectConfig(boolean enabled, int maxAttempts, Duration initialDelay,
                              Duration maxDelay, double jitterRatio) {
    public ReconnectConfig {
        Objects.requireNonNull(initialDelay); Objects.requireNonNull(maxDelay);
        if (maxAttempts < 0) throw new IllegalArgumentException("maxAttempts < 0");
        if (initialDelay.isNegative() || maxDelay.isNegative() || maxDelay.compareTo(initialDelay) < 0)
            throw new IllegalArgumentException("invalid reconnect delay");
        if (jitterRatio < 0 || jitterRatio > 1) throw new IllegalArgumentException("jitterRatio must be 0..1");
    }
    public static ReconnectConfig defaults() {
        return new ReconnectConfig(true, 3, Duration.ofSeconds(1), Duration.ofSeconds(30), 0.20);
    }
    public Duration delayForAttempt(int attempt) {
        if (attempt <= 0) return Duration.ZERO;
        long base = initialDelay.toMillis();
        long max = maxDelay.toMillis();
        long value = base;
        for (int i = 1; i < attempt && value < max; i++) value = Math.min(max, Math.max(1, value * 2));
        if (jitterRatio == 0 || value == 0) return Duration.ofMillis(value);
        long spread = Math.max(1, (long) (value * jitterRatio));
        long jittered = value - spread + ThreadLocalRandom.current().nextLong(spread * 2 + 1);
        return Duration.ofMillis(Math.max(0, Math.min(max, jittered)));
    }
}
