package com.example.instrument.core;

import com.example.instrument.connection.Connection;
import com.example.instrument.protocol.ProtocolDecoder;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

final class Receiver implements Runnable {
    private final Connection connection; private final ProtocolDecoder decoder; private final ResponseDispatcher dispatcher;
    private final int bufferSize; private final Consumer<Throwable> errorHandler;
    private volatile boolean running;
    Receiver(Connection connection,ProtocolDecoder decoder,ResponseDispatcher dispatcher,int bufferSize,Consumer<Throwable> errorHandler){
        this.connection=Objects.requireNonNull(connection);this.decoder=Objects.requireNonNull(decoder);this.dispatcher=Objects.requireNonNull(dispatcher);this.bufferSize=bufferSize;this.errorHandler=Objects.requireNonNull(errorHandler);
    }
    void stop(){running=false;}
    @Override public void run(){
        running=true;byte[] buffer=new byte[bufferSize];
        try{
            while(running && connection.isConnected()){
                int n=connection.read(buffer);
                if(n<0)throw new IOException("remote peer closed connection");
                if(n==0)continue;
                List<com.example.instrument.model.Response> frames=decoder.decode(buffer,0,n);
                for(var frame:frames)dispatcher.dispatch(frame);
            }
        }catch(Throwable t){if(running)errorHandler.accept(t);}finally{running=false;}
    }
}
