package com.example.instrument.connection;

import java.io.IOException;

public interface Connection extends AutoCloseable {
    void connect();
    int read(byte[] buffer) throws IOException;
    void write(byte[] data) throws IOException;
    boolean isConnected();
    ConnectionState state();
    @Override void close();
}
