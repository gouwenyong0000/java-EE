package com.example.instrument.connection;

import com.example.instrument.config.ClientConfig;
import com.example.instrument.exception.ConnectionException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Objects;
import java.util.concurrent.locks.ReentrantLock;

public final class TcpConnection implements Connection {
    private final InetSocketAddress address; private final ClientConfig config; private final ReentrantLock lifecycleLock=new ReentrantLock();
    private volatile Socket socket; private volatile InputStream input; private volatile OutputStream output; private volatile ConnectionState state=ConnectionState.NEW;
    public TcpConnection(InetSocketAddress address,ClientConfig config){this.address=Objects.requireNonNull(address);this.config=Objects.requireNonNull(config);}
    @Override public void connect(){
        lifecycleLock.lock();
        try {
            if(state==ConnectionState.CLOSED)throw new ConnectionException("connection is closed");
            if(state==ConnectionState.CONNECTED)return;
            state=ConnectionState.CONNECTING;
            Socket s=new Socket();
            try{
                s.setTcpNoDelay(config.tcpNoDelay()); s.setKeepAlive(config.keepAlive());
                s.setReceiveBufferSize(config.receiveBufferSize()); s.setSoTimeout(config.socketReadTimeoutMillis());
                s.connect(address,(int)Math.min(Integer.MAX_VALUE,config.connectTimeout().toMillis()));
                InputStream in=s.getInputStream(); OutputStream out=s.getOutputStream();
                socket=s;input=in;output=out;state=ConnectionState.CONNECTED;
            }catch(IOException e){try{s.close();}catch(IOException ignored){} state=ConnectionState.DISCONNECTED;throw new ConnectionException("connect failed: "+address,e);}
        } finally {lifecycleLock.unlock();}
    }
    @Override public int read(byte[] buffer)throws IOException{
        InputStream in=input; if(in==null||!isConnected())throw new IOException("not connected"); return in.read(buffer);
    }
    @Override public void write(byte[] data)throws IOException{
        OutputStream out=output; if(out==null||!isConnected())throw new IOException("not connected"); out.write(data);out.flush();
    }
    @Override public boolean isConnected(){Socket s=socket;return state==ConnectionState.CONNECTED&&s!=null&&s.isConnected()&&!s.isClosed();}
    @Override public ConnectionState state(){return state;}
    @Override public void close(){
        lifecycleLock.lock();
        try{if(state==ConnectionState.CLOSED)return;state=ConnectionState.CLOSING;closeQuietly(socket);socket=null;input=null;output=null;state=ConnectionState.CLOSED;}
        finally{lifecycleLock.unlock();}
    }
    public void disconnect(){
        lifecycleLock.lock();
        try{if(state==ConnectionState.CLOSED)return;closeQuietly(socket);socket=null;input=null;output=null;state=ConnectionState.DISCONNECTED;}
        finally{lifecycleLock.unlock();}
    }
    private static void closeQuietly(Socket s){if(s!=null)try{s.close();}catch(IOException ignored){}}
    @Override public String toString(){return "TcpConnection["+address+"]";}
}
