package com.example.instrument.model;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;

public final class Command {
    private final byte[] payload;

    private Command(byte[] payload) {
        this.payload = payload.clone();
    }

    public static Command of(byte[] payload) {
        Objects.requireNonNull(payload, "payload");
        return new Command(payload);
    }

    public static Command text(String text) {
        return text(text, StandardCharsets.UTF_8);
    }

    public static Command text(String text, Charset charset) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(charset, "charset");
        return new Command(text.getBytes(charset));
    }

    public byte[] bytes() { return payload.clone(); }
    public int length() { return payload.length; }

    @Override public String toString() { return "Command[length=" + payload.length + "]"; }
    @Override public boolean equals(Object o) {
        return o instanceof Command c && Arrays.equals(payload, c.payload);
    }
    @Override public int hashCode() { return Arrays.hashCode(payload); }
}
