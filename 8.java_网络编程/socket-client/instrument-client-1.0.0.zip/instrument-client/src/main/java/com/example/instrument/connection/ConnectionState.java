package com.example.instrument.connection;

public enum ConnectionState { NEW, CONNECTING, CONNECTED, DISCONNECTED, RECONNECTING, CLOSING, CLOSED }
