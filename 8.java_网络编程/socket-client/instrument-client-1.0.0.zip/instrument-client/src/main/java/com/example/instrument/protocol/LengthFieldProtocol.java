package com.example.instrument.protocol;

import com.example.instrument.exception.ProtocolException;
import com.example.instrument.model.Command;
import com.example.instrument.model.Response;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public final class LengthFieldProtocol implements Protocol {
    private final Charset charset; private final int maxPayloadLength;
    public LengthFieldProtocol(Charset charset,int maxPayloadLength){
        this.charset=Objects.requireNonNull(charset); if(maxPayloadLength<0||maxPayloadLength>65535)throw new IllegalArgumentException();this.maxPayloadLength=maxPayloadLength;
    }
    public static LengthFieldProtocol defaults(Charset charset){return new LengthFieldProtocol(charset,65535);}
    @Override public Charset charset(){return charset;}
    @Override public ProtocolEncoder newEncoder(){
        return command -> {
            byte[] payload=command.bytes(); if(payload.length>maxPayloadLength)throw new ProtocolException("payload too large: "+payload.length);
            byte[] out=new byte[payload.length+4]; out[0]=(byte)0xAA; out[1]=(byte)(payload.length>>>8); out[2]=(byte)payload.length;
            System.arraycopy(payload,0,out,3,payload.length); out[out.length-1]=checksum(out,0,out.length-1); return out;
        };
    }
    @Override public ProtocolDecoder newDecoder(){return new Decoder(maxPayloadLength);}
    private static byte checksum(byte[] b,int off,int len){byte x=0;for(int i=off;i<off+len;i++)x^=b[i];return x;}

    private static final class Decoder implements ProtocolDecoder {
        private final int max; private final ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        Decoder(int max){this.max=max;}
        @Override public synchronized List<Response> decode(byte[] data,int offset,int length){
            if(length==0)return List.of(); buffer.write(data,offset,length); List<Response> out=new ArrayList<>();
            while(true){
                byte[] b=buffer.toByteArray(); if(b.length<4)break;
                int stx=indexOfStx(b); if(stx<0){buffer.reset();break;}
                if(stx>0){buffer.reset();buffer.write(b,stx,b.length-stx);b=buffer.toByteArray();if(b.length<4)break;}
                int payloadLen=((b[1]&0xff)<<8)|(b[2]&0xff);
                if(payloadLen>max){discardOne();continue;}
                int total=4+payloadLen; if(b.length<total)break;
                byte expected=checksum(b,0,total-1); byte actual=b[total-1];
                if(expected!=actual){discardOne();continue;}
                byte[] frame=Arrays.copyOfRange(b,0,total); byte[] body=Arrays.copyOfRange(b,3,total-1); out.add(new Response(frame,body));
                buffer.reset(); if(b.length>total)buffer.write(b,total,b.length-total);
            }
            if(buffer.size()>max+4)throw new ProtocolException("binary buffer exceeds configured maximum");
            return out;
        }
        private int indexOfStx(byte[] b){for(int i=0;i<b.length;i++)if((b[i]&0xff)==0xAA)return i;return -1;}
        private void discardOne(){byte[] b=buffer.toByteArray();buffer.reset();if(b.length>1)buffer.write(b,1,b.length-1);}
        @Override public synchronized void reset(){buffer.reset();}
    }
}
