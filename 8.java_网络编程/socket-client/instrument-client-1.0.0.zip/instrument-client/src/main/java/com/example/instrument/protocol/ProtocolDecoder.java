package com.example.instrument.protocol;

import com.example.instrument.model.Response;
import java.util.List;

public interface ProtocolDecoder {
    List<Response> decode(byte[] data, int offset, int length);
    void reset();
}
