package com.example.instrument.core;

import com.example.instrument.api.*;
import com.example.instrument.config.ClientConfig;
import com.example.instrument.connection.*;
import com.example.instrument.exception.ConnectionException;
import com.example.instrument.exception.RequestTimeoutException;
import com.example.instrument.model.*;
import com.example.instrument.metrics.ClientMetrics;
import com.example.instrument.protocol.*;
import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantLock;

public final class InstrumentClientImpl implements InstrumentClient {
    private final InetSocketAddress address; private final Protocol protocol; private final ClientConfig config;
    private final TcpConnection connection; private final ProtocolEncoder encoder; private final ProtocolDecoder decoder;
    private final RequestManager requestManager=new RequestManager(); private final ClientMetrics metrics=new ClientMetrics();
    private final ResponseDispatcher dispatcher; private final ReconnectPolicy reconnectPolicy;
    private final ReentrantLock requestLock=new ReentrantLock(true); private final ReentrantLock lifecycleLock=new ReentrantLock(true);
    private final ExecutorService requestExecutor=Executors.newSingleThreadExecutor(r->new Thread(r,"instrument-request"));
    private final ScheduledExecutorService scheduler=Executors.newSingleThreadScheduledExecutor(r->new Thread(r,"instrument-reconnect"));
    private final CopyOnWriteArrayList<ConnectionListener> connectionListeners=new CopyOnWriteArrayList<>();
    private final AtomicBoolean reconnectScheduled=new AtomicBoolean();
    private volatile Receiver receiver; private volatile Thread receiverThread; private volatile boolean closed; private volatile boolean reconnectSuppressed=true;
    private volatile int reconnectAttempt;

    public InstrumentClientImpl(InetSocketAddress address,Protocol protocol,ClientConfig config){
        this.address=Objects.requireNonNull(address);this.protocol=Objects.requireNonNull(protocol);this.config=Objects.requireNonNull(config);
        this.connection=new TcpConnection(address,config);this.encoder=protocol.newEncoder();this.decoder=protocol.newDecoder();this.dispatcher=new ResponseDispatcher(requestManager,config,metrics);this.reconnectPolicy=new ReconnectPolicy(config.reconnect());
    }

    @Override public void connect(){
        lifecycleLock.lock();
        try{ensureNotClosed(); reconnectSuppressed=false; if(connection.isConnected())return; connection.connect(); decoder.reset(); startReceiver(); reconnectAttempt=0; notifyConnected();}
        finally{lifecycleLock.unlock();}
    }

    private void startReceiver(){
        Receiver old=receiver;if(old!=null)old.stop();
        Receiver r=new Receiver(connection,decoder,dispatcher,config.receiveBufferSize(),this::onReceiverFailure);receiver=r;
        Thread t=new Thread(r,"instrument-receiver");t.setDaemon(true);receiverThread=t;t.start();
    }

    private void onReceiverFailure(Throwable cause){
        if(closed)return;
        lifecycleLock.lock();
        try{
            if(!connection.isConnected()){}
            requestManager.fail(new ConnectionException("connection lost: "+address,cause));
            notifyDisconnected(cause);
            connection.disconnect();
            if(!reconnectSuppressed)scheduleReconnect(cause);
        }finally{lifecycleLock.unlock();}
    }

    private void scheduleReconnect(Throwable cause){
        if(!reconnectPolicy.enabled()||reconnectScheduled.getAndSet(true))return;
        reconnectAttempt=0; scheduleNextReconnect(cause);
    }
    private void scheduleNextReconnect(Throwable cause){
        int attempt=++reconnectAttempt;
        if(!reconnectPolicy.canAttempt(attempt)){reconnectScheduled.set(false);notifyReconnectFailed(cause);return;}
        Duration delay=reconnectPolicy.delay(attempt);notifyReconnecting(attempt,delay,cause);
        scheduler.schedule(()->{
            if(closed||reconnectSuppressed){reconnectScheduled.set(false);return;}
            try{connect();reconnectScheduled.set(false);}
            catch(Throwable e){scheduleNextReconnect(e);}
        },delay.toMillis(),TimeUnit.MILLISECONDS);
    }

    @Override public void disconnect(){
        lifecycleLock.lock();
        try{if(closed)return;reconnectSuppressed=true;reconnectScheduled.set(false);Receiver r=receiver;if(r!=null)r.stop();requestManager.fail(new ConnectionException("client disconnected"));connection.disconnect();decoder.reset();notifyDisconnected(null);}
        finally{lifecycleLock.unlock();}
    }

    @Override public boolean isConnected(){return connection.isConnected();}

    @Override public Response request(Command command,ResponseMatcher matcher,Duration timeout,CommandIdempotency idempotency){
        Objects.requireNonNull(command);Objects.requireNonNull(matcher);Objects.requireNonNull(timeout);Objects.requireNonNull(idempotency);
        Request request=new Request(command,matcher,timeout,idempotency);int attempts=0;
        while(true){
            try{return executeOnce(request);}
            catch(ConnectionException e){
                if(request.idempotency()!=CommandIdempotency.IDEMPOTENT || attempts>=reconnectPolicy.maxAttempts())throw e;
                attempts++; reconnectForRetry();
            }
        }
    }

    private Response executeOnce(Request request){
        requestLock.lock();
        PendingRequest pending=null;
        try{
            if(requestManager.hasPending())throw new IllegalStateException("another request is pending");
            if(!isConnected()) connect();
            pending=requestManager.register(request.matcher());
            try{connection.write(encoder.encode(request.command()));metrics.sent(request.command().length());}
            catch(Exception e){requestManager.remove(pending);onReceiverFailure(e);throw new ConnectionException("write failed: "+address,e);}
            try{return pending.future().get(request.timeout().toNanos(),TimeUnit.NANOSECONDS);}
            catch(TimeoutException e){requestManager.remove(pending);throw new RequestTimeoutException("request timeout after "+request.timeout()+": "+request.command());}
            catch(InterruptedException e){Thread.currentThread().interrupt();requestManager.remove(pending);throw new ConnectionException("request interrupted",e);}
            catch(ExecutionException e){requestManager.remove(pending);Throwable c=e.getCause();if(c instanceof ConnectionException ce)throw ce;throw new ConnectionException("request failed",c);}
        } finally {requestLock.unlock();}
    }

    private void reconnectForRetry(){
        lifecycleLock.lock();
        try{if(closed)throw new ConnectionException("client is closed");reconnectSuppressed=false;connection.disconnect();decoder.reset();connection.connect();startReceiver();notifyConnected();}
        catch(ConnectionException e){throw e;} finally{lifecycleLock.unlock();}
    }

    @Override public CompletableFuture<Response> requestAsync(Command command,ResponseMatcher matcher,Duration timeout,CommandIdempotency idempotency){
        return CompletableFuture.supplyAsync(()->request(command,matcher,timeout,idempotency),requestExecutor);
    }
    @Override public void send(Command command){
        requestLock.lock();
        try{if(requestManager.hasPending())throw new IllegalStateException("cannot send while a request is pending");if(!isConnected())connect();try{connection.write(encoder.encode(command));metrics.sent(command.length());}catch(Exception e){onReceiverFailure(e);throw new ConnectionException("write failed: "+address,e);}}
        finally{requestLock.unlock();}
    }
    @Override public void addDataListener(DataListener listener){dispatcher.addListener(listener);}
    @Override public void removeDataListener(DataListener listener){dispatcher.removeListener(listener);}
    @Override public void addConnectionListener(ConnectionListener listener){connectionListeners.add(Objects.requireNonNull(listener));}
    @Override public void removeConnectionListener(ConnectionListener listener){connectionListeners.remove(listener);}
    @Override public BlockingDataListener blockingDataListener(){return new BlockingDataListener(dispatcher.queue());}
    public ClientMetrics.Snapshot metrics(){return metrics.snapshot();}

    private void ensureNotClosed(){if(closed)throw new ConnectionException("client is closed");}
    private void notifyConnected(){for(var l:connectionListeners)try{l.onConnected();}catch(Throwable ignored){}}
    private void notifyDisconnected(Throwable cause){for(var l:connectionListeners)try{l.onDisconnected(cause);}catch(Throwable ignored){}}
    private void notifyReconnecting(int a,Duration d,Throwable c){for(var l:connectionListeners)try{l.onReconnecting(a,d,c);}catch(Throwable ignored){}}
    private void notifyReconnectFailed(Throwable c){for(var l:connectionListeners)try{l.onReconnectFailed(c);}catch(Throwable ignored){}}

    @Override public void close(){
        lifecycleLock.lock();
        try{if(closed)return;closed=true;reconnectSuppressed=true;reconnectScheduled.set(false);Receiver r=receiver;if(r!=null)r.stop();requestManager.fail(new ConnectionException("client closed"));connection.close();decoder.reset();}
        finally{lifecycleLock.unlock();}
        requestExecutor.shutdownNow();scheduler.shutdownNow();
    }
}
