package com.example.instrument.core;

import com.example.instrument.api.ResponseMatcher;
import com.example.instrument.model.Response;
import java.util.concurrent.atomic.AtomicReference;

final class RequestManager {
    private final AtomicReference<PendingRequest> pending=new AtomicReference<>();
    PendingRequest register(ResponseMatcher matcher){
        PendingRequest request=new PendingRequest(matcher);
        if(!pending.compareAndSet(null,request))throw new IllegalStateException("another request is already pending");
        return request;
    }
    boolean dispatch(Response response){
        PendingRequest request=pending.get();
        if(request==null)return false;
        if(!request.tryComplete(response))return false;
        pending.compareAndSet(request,null); return true;
    }
    void remove(PendingRequest request){pending.compareAndSet(request,null);}
    void fail(Throwable cause){PendingRequest r=pending.getAndSet(null);if(r!=null)r.future().completeExceptionally(cause);}
    boolean hasPending(){return pending.get()!=null;}
}
