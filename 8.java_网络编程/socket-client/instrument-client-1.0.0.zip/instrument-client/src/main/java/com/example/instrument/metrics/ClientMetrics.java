package com.example.instrument.metrics;

import java.util.concurrent.atomic.LongAdder;

public final class ClientMetrics {
    private final LongAdder sentFrames=new LongAdder(), sentBytes=new LongAdder(), receivedFrames=new LongAdder(), matchedFrames=new LongAdder(), asyncFrames=new LongAdder(), droppedAsync=new LongAdder(), listenerErrors=new LongAdder(), reconnects=new LongAdder(), timeouts=new LongAdder();
    public void sent(long bytes){sentFrames.increment();sentBytes.add(bytes);}
    public void receivedMatched(){receivedFrames.increment();matchedFrames.increment();}
    public void receivedAsync(){receivedFrames.increment();asyncFrames.increment();}
    public void droppedAsync(){droppedAsync.increment();}
    public void listenerErrors(){listenerErrors.increment();}
    public void reconnect(){reconnects.increment();}
    public void timeout(){timeouts.increment();}
    public Snapshot snapshot(){return new Snapshot(sentFrames.sum(),sentBytes.sum(),receivedFrames.sum(),matchedFrames.sum(),asyncFrames.sum(),droppedAsync.sum(),listenerErrors.sum(),reconnects.sum(),timeouts.sum());}
    public record Snapshot(long sentFrames,long sentBytes,long receivedFrames,long matchedFrames,long asyncFrames,long droppedAsync,long listenerErrors,long reconnects,long timeouts){}
}
