package com.example.instrument.api;

import com.example.instrument.model.Response;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.regex.Pattern;

@FunctionalInterface
public interface ResponseMatcher {
    boolean matches(Response response);

    static ResponseMatcher any() { return r -> true; }
    static ResponseMatcher predicate(Predicate<Response> predicate) {
        Objects.requireNonNull(predicate);
        return predicate::test;
    }
    static ResponseMatcher contains(String text) { return contains(text, StandardCharsets.UTF_8); }
    static ResponseMatcher contains(String text, Charset charset) {
        Objects.requireNonNull(text); Objects.requireNonNull(charset);
        return r -> r.text(charset).contains(text);
    }
    static ResponseMatcher equalsText(String text) { return equalsText(text, StandardCharsets.UTF_8); }
    static ResponseMatcher equalsText(String text, Charset charset) {
        Objects.requireNonNull(text); Objects.requireNonNull(charset);
        return r -> r.text(charset).equals(text);
    }
    static ResponseMatcher regex(String regex) { return regex(regex, StandardCharsets.UTF_8); }
    static ResponseMatcher regex(String regex, Charset charset) {
        Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
        return r -> pattern.matcher(r.text(charset)).matches();
    }
}
