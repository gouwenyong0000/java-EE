package com.example.instrument.api;

import com.example.instrument.model.Response;
import java.time.Duration;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public final class BlockingDataListener implements DataListener {
    private final BlockingQueue<Response> queue;

    public BlockingDataListener(BlockingQueue<Response> queue) { this.queue = queue; }
    @Override public void onData(Response response) { queue.offer(response); }
    public Response take() throws InterruptedException { return queue.take(); }
    public Response poll(Duration timeout) throws InterruptedException {
        return queue.poll(timeout.toNanos(), TimeUnit.NANOSECONDS);
    }
    public int size() { return queue.size(); }
}
