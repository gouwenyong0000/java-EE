package com.example.instrument.exception;

public class ConfigurationException extends InstrumentException {
    public ConfigurationException(String message) { super(message); }
}
