package com.example.instrument.model;

import com.example.instrument.api.ResponseMatcher;
import java.time.Duration;
import java.util.Objects;

public record Request(Command command, ResponseMatcher matcher, Duration timeout,
                      CommandIdempotency idempotency) {
    public Request {
        Objects.requireNonNull(command, "command");
        Objects.requireNonNull(matcher, "matcher");
        Objects.requireNonNull(timeout, "timeout");
        Objects.requireNonNull(idempotency, "idempotency");
        if (timeout.isZero() || timeout.isNegative()) throw new IllegalArgumentException("timeout must be > 0");
    }
}
