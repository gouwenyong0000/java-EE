package com.example.instrument.protocol;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public interface Protocol {
    ProtocolEncoder newEncoder();
    ProtocolDecoder newDecoder();
    default Charset charset() { return StandardCharsets.UTF_8; }
}
