package com.example.instrument.protocol;

import com.example.instrument.model.Command;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class LengthFieldProtocolTest {
    @Test void roundTrip(){
        LengthFieldProtocol p=LengthFieldProtocol.defaults(StandardCharsets.US_ASCII);
        byte[] frame=p.newEncoder().encode(Command.text("HELLO",StandardCharsets.US_ASCII));
        var d=p.newDecoder(); var a=d.decode(frame,0,2); assertTrue(a.isEmpty()); var b=d.decode(frame,2,frame.length-2);
        assertEquals(1,b.size()); assertEquals("HELLO",b.get(0).text(StandardCharsets.US_ASCII));
    }
    @Test void badChecksumIsResynchronized(){
        LengthFieldProtocol p=LengthFieldProtocol.defaults(StandardCharsets.US_ASCII);byte[] f=p.newEncoder().encode(Command.text("A",StandardCharsets.US_ASCII));f[f.length-1]^=1;
        var good=p.newEncoder().encode(Command.text("B",StandardCharsets.US_ASCII));byte[] all=new byte[f.length+good.length];System.arraycopy(f,0,all,0,f.length);System.arraycopy(good,0,all,f.length,good.length);
        var result=p.newDecoder().decode(all,0,all.length);assertEquals(1,result.size());assertEquals("B",result.get(0).text(StandardCharsets.US_ASCII));
    }
}
