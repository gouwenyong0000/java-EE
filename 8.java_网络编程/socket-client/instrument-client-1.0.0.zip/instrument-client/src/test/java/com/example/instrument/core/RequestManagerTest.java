package com.example.instrument.core;

import com.example.instrument.api.ResponseMatcher;
import com.example.instrument.model.Response;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RequestManagerTest {
    @Test void onlyMatchingResponseCompletesRequest(){
        RequestManager m=new RequestManager();PendingRequest p=m.register(ResponseMatcher.equalsText("OK",StandardCharsets.US_ASCII));
        assertFalse(m.dispatch(new Response("NO\r\n".getBytes(StandardCharsets.US_ASCII),"NO".getBytes(StandardCharsets.US_ASCII))));assertFalse(p.future().isDone());
        assertTrue(m.dispatch(new Response("OK\r\n".getBytes(StandardCharsets.US_ASCII),"OK".getBytes(StandardCharsets.US_ASCII))));assertEquals("OK",p.future().join().text(StandardCharsets.US_ASCII));
    }
}
