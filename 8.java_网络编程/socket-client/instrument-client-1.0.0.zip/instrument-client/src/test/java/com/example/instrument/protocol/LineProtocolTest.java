package com.example.instrument.protocol;

import com.example.instrument.model.Command;
import com.example.instrument.model.Response;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LineProtocolTest {
    @Test void supportsFragmentationAndStickyPackets(){
        LineProtocol p=LineProtocol.crlf(StandardCharsets.US_ASCII);
        ProtocolDecoder d=p.newDecoder();
        assertTrue(d.decode("HEL".getBytes(StandardCharsets.US_ASCII),0,3).isEmpty());
        var frames=d.decode("LO\r\nWORLD\r\n".getBytes(StandardCharsets.US_ASCII),0,"LO\r\nWORLD\r\n".getBytes(StandardCharsets.US_ASCII).length);
        assertEquals(2,frames.size()); assertEquals("HELLO",frames.get(0).text(StandardCharsets.US_ASCII)); assertEquals("WORLD",frames.get(1).text(StandardCharsets.US_ASCII));
    }
    @Test void encoderAddsCrlf(){
        byte[] actual=LineProtocol.crlf(StandardCharsets.US_ASCII).newEncoder().encode(Command.text("PING",StandardCharsets.US_ASCII));
        assertArrayEquals(new byte[]{'P','I','N','G','\r','\n'},actual);
    }
}
