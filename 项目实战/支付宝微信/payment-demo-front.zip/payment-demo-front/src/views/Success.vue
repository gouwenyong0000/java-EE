<template>
  <div class="bg-fa of" style="padding: 40px;">
    <el-alert
        title="支付成功！"
        type="success">
    </el-alert>
  </div>
</template>
