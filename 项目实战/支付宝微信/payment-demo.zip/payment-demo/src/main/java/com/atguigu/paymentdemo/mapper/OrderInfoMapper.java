package com.atguigu.paymentdemo.mapper;

import com.atguigu.paymentdemo.entity.OrderInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OrderInfoMapper extends BaseMapper<OrderInfo> {

}
