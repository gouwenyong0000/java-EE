package com.atguigu.paymentdemo.mapper;

import com.atguigu.paymentdemo.entity.PaymentInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface PaymentInfoMapper extends BaseMapper<PaymentInfo> {
}
